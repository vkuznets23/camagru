(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_zxcvbn_lib_b9bcfa69._.js",
  "static/chunks/node_modules_react-icons_bi_index_mjs_cba0e860._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/_8f04f51d._.js"
],
    source: "dynamic"
});
