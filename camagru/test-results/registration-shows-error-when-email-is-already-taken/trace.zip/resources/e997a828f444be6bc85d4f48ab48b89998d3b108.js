(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__ee07e3de._.css",
  "static/chunks/node_modules_74b9144f._.js",
  "static/chunks/_12665943._.js"
],
    source: "dynamic"
});
